package com.e.tugaskeempat.View;

import com.e.tugaskeempat.Model.BrModel;
import java.util.List;

public interface MainView {
    void onSuccess(List<BrModel> brModels);
}