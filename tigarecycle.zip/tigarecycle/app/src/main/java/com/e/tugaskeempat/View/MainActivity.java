package com.e.tugaskeempat.View;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import com.e.tugaskeempat.Adapter.BrAdapter;
import com.e.tugaskeempat.Model.BrModel;
import com.e.tugaskeempat.Presenter.BrPresenter;
import com.e.tugaskeempat.R;
import java.util.ArrayList;
import java.util.List;
public class MainActivity extends AppCompatActivity implements MainView {
    RecyclerView rvTim,rvTim1,rvTim2;
    BrAdapter adapter;
    BrPresenter data;
    List<BrModel> brModels = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        rvTim = findViewById(R.id.rc);
        rvTim1 = findViewById(R.id.rc1);
        rvTim2 = findViewById(R.id.rc2);

        rvTim.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL,false));
        adapter = new BrAdapter(this, brModels);
        rvTim.setAdapter(adapter);
        data = new BrPresenter(this,this);
        data.setData();

        rvTim1.setLayoutManager(new GridLayoutManager(MainActivity.this,2));
        adapter = new BrAdapter(this, brModels);
        rvTim1.setAdapter(adapter);
        data = new BrPresenter(this,this);
        data.setData();

        rvTim2.setLayoutManager(new LinearLayoutManager(this));
        adapter = new BrAdapter(this, brModels);
        rvTim2.setAdapter(adapter);
        data = new BrPresenter(this,this);
        data.setData();
    }
    public void onSuccess(List<BrModel> brModels){
        this.brModels.clear();
        this.brModels.addAll(brModels);
        this.adapter.notifyDataSetChanged();
    }
}