package com.e.tugaskeempat.Adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import com.e.tugaskeempat.Model.BrModel;
import com.e.tugaskeempat.R;
import java.util.ArrayList;
import java.util.List;

public class BrAdapter extends RecyclerView.Adapter<BrAdapter.ViewHolder> {
    Context context;
    List<BrModel> brModels = new ArrayList<>();
    public BrAdapter(Context context, List<BrModel> brModels) {
        this.context = context;
        this.brModels = brModels;
    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.activity_item, viewGroup, false);
        ViewHolder holder = new ViewHolder(view);
        return holder;
    }
    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int i) {
        viewHolder.onBind(brModels.get(i));
    }
    @Override
    public int getItemCount() {
        return brModels.size();
    }
    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView ivPic;
        TextView tvText;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            ivPic = itemView.findViewById(R.id.pic);
            tvText = itemView.findViewById(R.id.tv);
        }
        public void onBind(final BrModel br) {
            ivPic.setImageResource(br.getPicTim());
            tvText.setText(br.getNamaTim());
            itemView.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
            Toast.makeText(context, br.getNamaTim(), Toast.LENGTH_LONG).show(); }});
        }
    }
}