package com.e.tugaskeempat.Presenter;

import android.content.Context;

import com.e.tugaskeempat.View.MainView;
import com.e.tugaskeempat.Model.BrModel;
import com.e.tugaskeempat.R;

import java.util.ArrayList;
import java.util.List;

public class BrPresenter {
    Context context;
    List<BrModel> brModels = new ArrayList<>();
    MainView view;
    public BrPresenter(MainView view, Context context){
        this.view=view;
        this.context=context;
    }
    public void setData(){
        BrModel tim;
        tim= new BrModel("AC Milan", R.drawable.img_acm);
        brModels.add(tim);
        tim= new BrModel("FC Barcelona", R.drawable.img_barca);
        brModels.add(tim);
        tim= new BrModel("Real Madrid", R.drawable.img_madrid);
        brModels.add(tim);
        tim= new BrModel("Manchester United", R.drawable.img_mu);
        brModels.add(tim);
        view.onSuccess(brModels);
    }
}

