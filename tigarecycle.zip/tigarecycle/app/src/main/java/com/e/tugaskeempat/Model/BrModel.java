package com.e.tugaskeempat.Model;

public class BrModel {
        String namaTim;
        int picTim;
        public BrModel(String namaTim,int picTim){
            this.namaTim = namaTim;
            this.picTim = picTim;
        }
        public String getNamaTim() {
            return namaTim;
        }
        public int getPicTim() { return picTim; }}